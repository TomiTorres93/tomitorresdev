const tomi = document.querySelector('#tomi')
const torres = document.querySelector('#torres')
const developer = document.querySelector('#developer')
const punto = document.querySelector('#punto')


const omi = document.querySelector('#omi')
const orres = document.querySelector('#orres')
const eveloper = document.querySelector('#eveloper')
const proximamente = document.querySelector('#proximamente')


tomi.addEventListener('mouseenter', function () {


    omi.classList.add('side');
    omi.classList.remove('hide');

})

torres.addEventListener('mouseenter', function () {


    orres.classList.add('side');
    orres.classList.remove('hide');

})

developer.addEventListener('mouseenter', function () {


    eveloper.classList.add('side');
    eveloper.classList.remove('hide');

})

punto.addEventListener('mouseenter', function () {


    proximamente.classList.add('side');
    proximamente.classList.remove('hide');

})